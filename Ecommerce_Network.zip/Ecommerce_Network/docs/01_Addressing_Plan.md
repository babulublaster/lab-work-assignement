# Addressing Plan

Domain: **shopnow.com**  |  Lab passwords: enable `Cisco@123`, SSH user `admin` / `Admin@123`

## VLANs and subnets
| VLAN | Name | Subnet | Gateway (R1 sub-if) | DHCP range | Switch ports |
|---|---|---|---|---|---|
| 10 | SALES | 192.168.10.0/24 | 192.168.10.1 | .10 - .254 | SW1 Fa0/1 |
| 20 | CUSTOMER-SUPPORT | 192.168.20.0/24 | 192.168.20.1 | .10 - .254 | SW1 Fa0/2 |
| 30 | LOGISTICS | 192.168.30.0/24 | 192.168.30.1 | .10 - .254 | SW1 Fa0/3 |
| 40 | FINANCE | 192.168.40.0/24 | 192.168.40.1 | .10 - .254 | SW1 Fa0/4 |
| 50 | IT | 192.168.50.0/24 | 192.168.50.1 | .10 - .254 | SW1 Fa0/5 |
| 100 | SERVER-FARM | 192.168.100.0/24 | 192.168.100.1 | static only | SW2 Fa0/1-5 |
| 999 | UNUSED | - | - | - | unused ports (shutdown) |

## Static addresses
| Device | IP | Mask | Gateway | DNS | Services |
|---|---|---|---|---|---|
| R1-CORE Gi0/0.10 - .50 | .1 of each user subnet | /24 | - | - | Gateways + DHCP |
| R1-CORE Gi0/1.100 | 192.168.100.1 | /24 | - | - | Server gateway + ACL |
| SW1-ACCESS (Vlan50) | 192.168.50.2 | /24 | 192.168.50.1 | - | Management |
| SW2-SERVER (Vlan100) | 192.168.100.2 | /24 | 192.168.100.1 | - | Management |
| WebServer | 192.168.100.10 | /24 | 192.168.100.1 | 192.168.100.20 | HTTP, HTTPS, FTP |
| DBServer | 192.168.100.11 | /24 | 192.168.100.1 | 192.168.100.20 | Database (3306) |
| PortalServer | 192.168.100.12 | /24 | 192.168.100.1 | 192.168.100.20 | HTTP, HTTPS |
| DNSServer | 192.168.100.20 | /24 | 192.168.100.1 | 192.168.100.20 | DNS |
| MailServer | 192.168.100.30 | /24 | 192.168.100.1 | 192.168.100.20 | SMTP, POP3 |

## Cabling (all copper straight-through)
| From | To |
|---|---|
| R1-CORE Gi0/0 | SW1-ACCESS Gi0/1 (trunk) |
| R1-CORE Gi0/1 | SW2-SERVER Gi0/1 (trunk) |
| SW1 Fa0/1 - Fa0/5 | PC-Sales, PC-Support, PC-Logistics, PC-Finance, PC-IT |
| SW2 Fa0/1 - Fa0/5 | WebServer, DBServer, PortalServer, DNSServer, MailServer |

## Access policy (ACL SERVER_ACCESS, outbound on R1 Gi0/1.100)
| Traffic to server farm | Who is allowed |
|---|---|
| DNS (53) to 192.168.100.20 | All user VLANs |
| HTTP/HTTPS to Web (.10) and Portal (.12) | All user VLANs |
| SMTP/POP3 to Mail (.30) | All user VLANs |
| FTP (20/21) to Web (.10) | IT and Logistics only |
| Database (3306) to DB (.11) | IT only |
| ICMP to server farm | IT only (troubleshooting) |
| Everything else | Denied |
