# Server Settings (Packet Tracer: click server > Config / Services tab)

Use **Server-PT** for all five. In Config > FastEthernet0 set the static IP, mask, gateway and DNS from the addressing plan.

## DNSServer (192.168.100.20) - Services > DNS > On
| Name | Type | Address |
|---|---|---|
| www.shopnow.com | A Record | 192.168.100.10 |
| portal.shopnow.com | A Record | 192.168.100.12 |
| mail.shopnow.com | A Record | 192.168.100.30 |
| db.shopnow.com | A Record | 192.168.100.11 |
| dns.shopnow.com | A Record | 192.168.100.20 |

## WebServer (192.168.100.10)
- Services > HTTP: HTTP **On**, HTTPS **On**. Edit `index.html` to: `<h1>ShopNow Online Store</h1>`
- Services > FTP: **On**. Add users (delete the default `cisco` user):
  | Username | Password | Permissions |
  |---|---|---|
  | itadmin | Ftp@123 | Write, Read, Delete, Rename, List |
  | logistics | Ftp@123 | Write, Read, List |

## PortalServer (192.168.100.12)
- Services > HTTP: **On**, HTTPS **On**. Edit `index.html` to: `<h1>ShopNow Customer Portal</h1>`

## DBServer (192.168.100.11)
- Packet Tracer has no database engine, so this host represents the DB tier. Turn HTTP, HTTPS, FTP, Email and DNS **Off**.
- The ACL (TCP 3306 from IT only) is what enforces access to it.

## MailServer (192.168.100.30) - Services > EMAIL
- SMTP **On**, POP3 **On**. Domain Name: `shopnow.com` > Set.
- Users (all password `Mail@123`): sales, support, logistics, finance, itadmin

## PCs (Config > FastEthernet0 > **DHCP**)
Desktop > Email on each PC:
- Your Name: e.g. Sales User
- Email Address: `sales@shopnow.com` (support@, logistics@, finance@, itadmin@ for the others)
- Incoming / Outgoing Mail Server: `mail.shopnow.com`
- User Name: `sales` (etc.)  |  Password: `Mail@123`
