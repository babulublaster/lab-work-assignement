# Test Plan and Results
Fill the "Actual" column and attach screenshots as you run each test in Packet Tracer.

## A. Basic connectivity and DHCP
| # | Test | Expected | Actual |
|---|---|---|---|
| A1 | Each PC: `ipconfig /all` | IP from its own subnet, gateway .1, DNS 192.168.100.20 | |
| A2 | R1: `show ip dhcp binding` | 5 leases, one per VLAN | |
| A3 | SW1: `show vlan brief`, `show interfaces trunk` | VLANs 10-50 with correct ports; Gi0/1 trunking | |
| A4 | SW2: `show vlan brief` | VLAN 100 with Fa0/1-5 | |
| A5 | R1: `show ip interface brief` | All sub-interfaces up/up | |

## B. Website access (IP and domain)
| # | Test | Expected | Actual |
|---|---|---|---|
| B1 | PC-Sales browser: `http://192.168.100.10` | ShopNow Online Store | |
| B2 | PC-Sales browser: `http://www.shopnow.com` | ShopNow Online Store (DNS works) | |
| B3 | PC-Finance browser: `http://portal.shopnow.com` | ShopNow Customer Portal | |
| B4 | PC-Support cmd: `nslookup www.shopnow.com` | 192.168.100.10 | |

## C. Email
| # | Test | Expected | Actual |
|---|---|---|---|
| C1 | PC-Sales: Email > Compose to `support@shopnow.com`, Send | Mail sent successfully | |
| C2 | PC-Support: Email > Receive | Message from sales@shopnow.com appears | |
| C3 | PC-Finance sends to `itadmin@shopnow.com`; PC-IT receives | Works | |

## D. FTP (authorized transfer)
| # | Test | Expected | Actual |
|---|---|---|---|
| D1 | PC-IT cmd: `ftp 192.168.100.10`, user `itadmin` / `Ftp@123` | Login OK; `dir`, `put`/`get` work | |
| D2 | PC-Logistics: same with user `logistics` | Login OK | |
| D3 | PC-Sales: `ftp 192.168.100.10` | **Fails / times out** (ACL) | |
| D4 | PC-Finance: `ftp 192.168.100.10` | **Fails / times out** (ACL) | |
| D5 | PC-IT: FTP with wrong password | Login rejected | |

## E. Access restrictions (security)
| # | Test | Expected | Actual |
|---|---|---|---|
| E1 | PC-IT: `ping 192.168.100.11` | Reply (IT allowed ICMP) | |
| E2 | PC-Sales: `ping 192.168.100.11` | Timed out / unreachable (ACL) | |
| E3 | PC-Sales: `ping 192.168.100.10` | Timed out / unreachable (ACL) | |
| E4 | PC-Sales: browse `http://192.168.100.11` | Fails (DB not reachable by users) | |
| E5 | R1: `show access-lists SERVER_ACCESS` | Hit counters increase on permit/deny lines | |
| E6 | PC-Sales: ping PC-Finance | Succeeds (inter-VLAN routing works) | |
| E7 | Swap the PC on SW1 Fa0/1 for a different one | Port security restricts new MAC (`show port-security`) | |

## Evidence checklist for submission
- Screenshot of the labelled topology (`docs/Topology.png` is a reference layout)
- `show running-config` of R1-CORE, SW1-ACCESS, SW2-SERVER
- `show vlan brief`, `show ip dhcp binding`, `show access-lists`
- Screenshots of tests A1 - E7
- The addressing plan (`01_Addressing_Plan.md`)
