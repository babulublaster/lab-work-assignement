# E-Commerce Company Network - Packet Tracer Project

## Build steps (about 15 minutes)
1. **Place devices**: 1x Router 2911 (R1-CORE), 2x Switch 2960 (SW1-ACCESS, SW2-SERVER), 5x PC (Sales, Support, Logistics, Finance, IT), 5x Server-PT (WebServer, DBServer, PortalServer, DNSServer, MailServer). Rename each.
2. **Cable** with copper straight-through as per `docs/01_Addressing_Plan.md` (see `docs/Topology.png`).
3. **Paste configs** into each device CLI tab: `configs/SW1-ACCESS.txt`, `configs/SW2-SERVER.txt`, then `configs/R1-CORE.txt`.
   - Wait for the links to turn green (~30 s) before testing.
4. **Configure servers** (IP, DNS, HTTP, FTP, email) using `docs/02_Server_Settings.md`.
5. **Set PCs to DHCP** and configure Email on each.
6. **Run tests** from `docs/03_Test_Plan_and_Results.md`, capture screenshots.
7. **File > Save As** `Ecommerce_Network.pkt`.

## Notes
- If SW1 or SW2 pastes stop at `crypto`/`range` lines, paste in smaller chunks.
- Servers must be set to a static IP before DNS/Email tests.
- Port-security uses sticky MACs; if you swap a PC, run `clear port-security sticky` on that port or shut/no shut it.
